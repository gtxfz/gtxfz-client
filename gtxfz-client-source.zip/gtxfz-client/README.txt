gtxfz client (Fabric, Minecraft 1.21.11)

BUILD:
  1. Install JDK 21.
  2. Generate a Gradle wrapper (or copy one from the template at fabricmc.net/develop):  gradle wrapper
  3. Check gradle.properties versions against fabricmc.net/develop for 1.21.11.
  4. ./gradlew build   ->  build/libs/gtxfz-client-1.0.0.jar
  Put the jar (not -sources) in .minecraft/mods with Fabric Loader + Fabric API.

COMMANDS (in chat):
  /gtxfz list
  /gtxfz <module>                 toggle  (automace, maceswap, stunslam, pearlcatch, spearreach)
  /gtxfz <module> <setting> <n>   e.g. /gtxfz stunslam delay 3   /gtxfz stunslam back 2

NO-INSTALL BUILD (GitHub):
  1. Make a free GitHub account, create a new repository, upload ALL files in this folder (including the hidden .github folder).
  2. Open the repo's Actions tab -> the "build" run -> Artifacts -> download gtxfz-client-jar.
  3. Unzip it; use gtxfz-client-1.0.0.jar (not the -sources one).
  If the build fails on Gradle/Loom versions, change gradle-version in .github/workflows/build.yml or the versions in gradle.properties.
