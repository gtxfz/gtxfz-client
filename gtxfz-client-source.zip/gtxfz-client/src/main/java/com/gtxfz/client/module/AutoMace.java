package com.gtxfz.client.module;

import com.gtxfz.client.Swap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Automatically smash-attacks whatever is under your crosshair while you fall. */
public class AutoMace extends Module {
    public AutoMace() {
        super("automace");
        setting("minfall", 2.5);
        setting("breach", 1);
        setting("back", 1);
        setting("playersonly", 1);
    }

    @Override
    public void tick() {
        var mc = Minecraft.getInstance();
        var p = mc.player;
        if (!(mc.hitResult instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity t)) return;
        if (!t.isAlive() || (flag("playersonly") && !(t instanceof net.minecraft.world.entity.player.Player))) return;
        if (p.onGround() || p.fallDistance < get("minfall") || p.getAttackStrengthScale(0.5f) < 0.9f) return;
        int slot = Swap.maceSlot(flag("breach"));
        if (slot < 0) return;
        Swap.hitSwapped(t, slot, (int) get("back"));
    }
}
