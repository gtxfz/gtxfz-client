package com.gtxfz.client;

import com.gtxfz.client.module.*;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import java.util.List;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;

public class GtxfzClient implements ClientModInitializer {
    public static final List<Module> MODULES = List.of(
            new AutoMace(), new MaceSwap(), new StunSlam(), new PearlCatch(), new SpearReach());

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.level == null || mc.gameMode == null) return;
            Swap.tick();
            for (Module m : MODULES) if (m.enabled) m.tick();
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClientSide() || Swap.busy || !(entity instanceof LivingEntity)) return InteractionResult.PASS;
            // Priority: stunslam hook, then spear/mace attribute swap, then mace swap.
            boolean handled = false;
            for (String n : new String[]{"stunslam", "spearreach", "maceswap"}) {
                for (Module m : MODULES) {
                    if (m.enabled && m.name.equals(n) && !handled) handled = m.onAttack(entity);
                }
            }
            return InteractionResult.PASS;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClientSide() && !Swap.busy) for (Module m : MODULES) if (m.enabled) m.onUse();
            return InteractionResult.PASS;
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> {
            var root = ClientCommandManager.literal("gtxfz");
            for (Module m : MODULES) {
                var node = ClientCommandManager.literal(m.name).executes(c -> {
                    m.enabled = !m.enabled;
                    msg(c.getSource(), m.name + (m.enabled ? " ON" : " OFF"));
                    return 1;
                });
                for (String s : m.settings.keySet()) {
                    node.then(ClientCommandManager.literal(s).then(
                            ClientCommandManager.argument("value", DoubleArgumentType.doubleArg())
                                    .executes(c -> {
                                        double v = DoubleArgumentType.getDouble(c, "value");
                                        m.settings.put(s, v);
                                        msg(c.getSource(), m.name + " " + s + " = " + v);
                                        return 1;
                                    })));
                }
                root.then(node);
            }
            root.then(ClientCommandManager.literal("list").executes(c -> {
                for (Module m : MODULES) msg(c.getSource(), m.name + (m.enabled ? " [ON] " : " [off] ") + m.settings);
                return 1;
            }));
            dispatcher.register(root);
        });
    }

    private static void msg(FabricClientCommandSource src, String s) {
        src.sendFeedback(Component.literal("[gtxfz] " + s));
    }
}
