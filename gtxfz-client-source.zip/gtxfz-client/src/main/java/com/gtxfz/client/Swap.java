package com.gtxfz.client;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

public final class Swap {
    private static final Minecraft mc = Minecraft.getInstance();
    /** True while the client itself is sending an attack, so hooks don't re-trigger. */
    public static boolean busy;

    private static final class Task { int ticks; Runnable run; }
    private static final List<Task> tasks = new ArrayList<>();

    public static void later(int ticks, Runnable r) {
        Task t = new Task(); t.ticks = ticks; t.run = r; tasks.add(t);
    }

    public static void tick() {
        for (Task t : new ArrayList<>(tasks)) {
            if (--t.ticks <= 0) { tasks.remove(t); t.run.run(); }
        }
    }

    public static int current() { return mc.player.getInventory().getSelectedSlot(); }
    public static void select(int slot) { if (slot >= 0 && slot <= 8) mc.player.getInventory().setSelectedSlot(slot); }

    public static int find(Predicate<ItemStack> p) {
        for (int i = 0; i < 9; i++) if (p.test(mc.player.getInventory().getItem(i))) return i;
        return -1;
    }

    public static int breachLevel(ItemStack st) {
        var reg = mc.level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        return EnchantmentHelper.getItemEnchantmentLevel(reg.getOrThrow(Enchantments.BREACH), st);
    }

    public static int maceSlot(boolean preferBreach) {
        int any = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack st = mc.player.getInventory().getItem(i);
            if (!st.is(Items.MACE)) continue;
            if (!preferBreach || breachLevel(st) > 0) return i;
            if (any < 0) any = i;
        }
        return any;
    }

    public static int spearSlot() { return find(s -> s.is(net.minecraft.tags.ItemTags.SPEARS)); }

    public static boolean isCrit(Player p) {
        return p.getAttackStrengthScale(0.5f) > 0.9f && p.fallDistance > 0.0
                && !p.onGround() && !p.onClimbable() && !p.isInWater()
                && !p.hasEffect(MobEffects.BLINDNESS) && !p.isPassenger();
    }

    /** Swap now, let the click that triggered us go through, swap back after backTicks. */
    public static void swapFor(int slot, int backTicks) {
        int prev = current();
        if (slot < 0 || slot == prev) return;
        select(slot);
        later(Math.max(1, backTicks), () -> select(prev));
    }

    /** Swap, attack the target ourselves, swap back after backTicks. */
    public static void hitSwapped(Entity target, int slot, int backTicks) {
        int prev = current();
        if (slot >= 0) select(slot);
        busy = true;
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
        busy = false;
        if (slot >= 0 && slot != prev) later(Math.max(1, backTicks), () -> select(prev));
    }
}
