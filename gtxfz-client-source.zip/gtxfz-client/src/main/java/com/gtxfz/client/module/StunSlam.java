package com.gtxfz.client.module;

import com.gtxfz.client.Swap;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Axe a blocking player, then slam with the mace after a configurable delay. */
public class StunSlam extends Module {
    public StunSlam() {
        super("stunslam");
        setting("delay", 2);   // ticks between the axe hit and the mace slam
        setting("back", 1);    // ticks before swapping back to the axe
        setting("breach", 1);  // prefer breach mace for the slam
    }

    @Override
    public boolean onAttack(Entity target) {
        var mc = Minecraft.getInstance();
        if (!(target instanceof Player victim) || !victim.isBlocking()) return false;
        if (!mc.player.getMainHandItem().is(ItemTags.AXES)) return false;
        Swap.later((int) get("delay"), () -> {
            if (mc.player == null || !victim.isAlive()) return;
            int slot = Swap.maceSlot(flag("breach"));
            if (slot >= 0) Swap.hitSwapped(victim, slot, (int) get("back"));
        });
        return false; // the axe hit itself goes through normally
    }
}
