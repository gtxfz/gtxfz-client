package com.gtxfz.client.module;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.entity.Entity;

public abstract class Module {
    public final String name;
    public boolean enabled;
    public final Map<String, Double> settings = new LinkedHashMap<>();

    protected Module(String name) { this.name = name; }

    protected void setting(String key, double def) { settings.put(key, def); }
    public double get(String key) { return settings.get(key); }
    public boolean flag(String key) { return get(key) >= 0.5; }

    public void tick() {}
    /** Called when the player clicks on an entity. Return true if this module handled the swap. */
    public boolean onAttack(Entity target) { return false; }
    /** Called when the player right-clicks with an item. */
    public void onUse() {}
}
