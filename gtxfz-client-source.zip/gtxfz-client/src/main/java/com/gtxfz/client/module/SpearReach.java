package com.gtxfz.client.module;

import com.gtxfz.client.Swap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.projectile.ProjectileUtil;

/**
 * Attribute swap: the attack is sent while the chosen item (spear or mace) is selected,
 * so the server uses that item's attributes/attack range. Also reaches past vanilla range.
 */
public class SpearReach extends Module {
    public SpearReach() {
        super("spearreach");
        setting("item", 0);    // 0 = swap to spear, 1 = swap to mace
        setting("reach", 4.5); // extra-reach targeting distance
        setting("back", 1);
        setting("breach", 1);
    }

    private int slot() { return get("item") < 0.5 ? Swap.spearSlot() : Swap.maceSlot(flag("breach")); }

    @Override
    public boolean onAttack(Entity target) {
        int s = slot();
        if (s < 0 || s == Swap.current()) return false;
        Swap.swapFor(s, (int) get("back"));
        return true;
    }

    @Override
    public void tick() {
        var mc = Minecraft.getInstance();
        var p = mc.player;
        if (!mc.options.keyAttack.isDown() || p.getAttackStrengthScale(0.5f) < 0.9f) return;
        if (mc.hitResult instanceof EntityHitResult) return; // vanilla click already has a target
        double reach = get("reach");
        Vec3 from = p.getEyePosition(), look = p.getViewVector(1f), to = from.add(look.scale(reach));
        AABB box = p.getBoundingBox().expandTowards(look.scale(reach)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p, from, to, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator(), reach * reach);
        if (hit == null) return;
        int s = slot();
        if (s < 0) return;
        Swap.hitSwapped(hit.getEntity(), s, (int) get("back"));
    }
}
