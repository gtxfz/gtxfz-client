package com.gtxfz.client.module;

import com.gtxfz.client.Swap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;

/** Swaps to your (breach) mace on click while falling or critting, then swaps back. */
public class MaceSwap extends Module {
    public MaceSwap() {
        super("maceswap");
        setting("breach", 1);     // 1 = prefer a Breach mace (breach swap)
        setting("crit", 1);       // swap when a crit is possible
        setting("smash", 1);      // swap when falling far enough for a smash attack
        setting("minfall", 1.5);  // fall distance for smash
        setting("back", 1);       // ticks before swapping back
    }

    @Override
    public boolean onAttack(Entity target) {
        var p = Minecraft.getInstance().player;
        boolean ok = (flag("crit") && Swap.isCrit(p)) || (flag("smash") && p.fallDistance >= get("minfall"));
        if (!ok) return false;
        var held = p.getMainHandItem();
        if (held.is(Items.MACE) && (!flag("breach") || Swap.breachLevel(held) > 0)) return false;
        int slot = Swap.maceSlot(flag("breach"));
        if (slot < 0) return false;
        Swap.swapFor(slot, (int) get("back"));
        return true;
    }
}
