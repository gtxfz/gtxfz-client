package com.gtxfz.client.module;

import com.gtxfz.client.Swap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** When you throw an ender pearl, auto-fires a wind charge after a delay to time your catch. */
public class PearlCatch extends Module {
    public PearlCatch() {
        super("pearlcatch");
        setting("delay", 8);  // ticks after the pearl throw
        setting("back", 1);
    }

    @Override
    public void onUse() {
        var mc = Minecraft.getInstance();
        if (!mc.player.getMainHandItem().is(Items.ENDER_PEARL)) return;
        int prev = Swap.current();
        Swap.later((int) get("delay"), () -> {
            if (mc.player == null) return;
            int slot = Swap.find(s -> s.is(Items.WIND_CHARGE));
            if (slot < 0) return;
            Swap.select(slot);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            Swap.later((int) get("back"), () -> Swap.select(prev));
        });
    }
}
